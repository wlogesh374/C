#include<stdio.h>
void main()
{
    int i,j;
    int a[2][3]={{1,2,3},{4,5,6}};
    
    for(i=0;i<2;i=i+1)
    {
        for(j=0;j<3;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
}