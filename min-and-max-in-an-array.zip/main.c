#include <stdio.h>
int main()
{
    int i, sum=0;
    int a[100];
    printf("Enter the values; ");
    for (i=0;i<5;i++)
    {
        scanf ("%d",&a[i]);
        
    }
    int min, max ;
    min=max=a[0];
    for(i=0;i<5;i++)
    {
        if(max<a[i])
        {
          max=a[i];
            
        }
        else if(min>a[i])
        {
            min=a[i];
        }
    }
    
 
    printf ("%d %d",max,min);
    
    
}
