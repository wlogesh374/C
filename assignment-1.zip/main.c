#include <stdio.h>

int main()
{
    int mark1,mark2,mark3,mark4,mark5,avg;
    
    printf("Enter your mark1 mark2 mark3 mark4 mark5 \n");
    scanf("%d%d%d%d%d",&mark1,&mark2,&mark3,&mark4,&mark5);
    avg=(mark1+mark2+mark3+mark4+mark5)/5;
    printf("Average is %d\n",avg);
    if(avg<60)
    {
    printf("%d is fail",avg);
    }
    else
    {
        printf("%d is pass",avg);
    }
    return 0;
}

