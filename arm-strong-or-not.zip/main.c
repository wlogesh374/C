#include <stdio.h>

int main()
{
  int num,rem,result=0,d;
  scanf("%d",&num);
  d=num;
  while(num>0)
  {
      rem=num%10;
      num=num/10;
      result=result + (rem * rem* rem);
      
  }
  if(result==d)
  {
      printf("%d is a arm strong number.",d);
  }
  else
  {
      printf("%d is not a arm strong number.",d);
  }
}
