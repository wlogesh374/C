#include <stdio.h>

void main()
{
int i,j;
char a[3][4]={{'r','a','t','h'},{'i','n','a','m'},{'t','e','c','h'}};
  
  for(i=0;i<3;i=i+1)
  {
      for(j=0;j<4;j++)
      {
          if(a[i][j]=='n')
          {
              printf("row and column is %d %d",i,j);
          }
      }
  }

}
