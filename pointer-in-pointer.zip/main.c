#include <stdio.h>
int main()
{
    int i=10;
    int *p,*q;
    p=&i;
    q=p;
    printf("the value of i=%d\n",i);
    printf("the address value of i=%d\n",&i);
    printf("the value of *p=%d\n",*p);
        printf("the value of *q=%d\n",*q);
    printf("the value of p=%d\n",p);
    printf("the value of q=%d\n",p);

}