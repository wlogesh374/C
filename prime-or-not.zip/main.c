
#include <stdio.h>

int main()
{
   int num , i,flag=0;
   scanf("%d",&num);
   for(i=2;i<num;i++)
   {
       if(num%i==0)
       {
       flag=1;
       break;
       }
       else
       {
           flag=0;
           
       }
       
   }
   if(flag==0)
   {
       printf("prime");
   }
   else
   {
       printf(" not prime");
   }
   
}
