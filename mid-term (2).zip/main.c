#include<stdio.h>
int main()
{
    int i,k,m;
    int a[7]={ 5,8,2};
    for(i=0;i<=2;i++)
    {
        k=a[1]/a[2];
    }

printf("'8' is %d times of 2\n",k);

int b[5]={3,4,1};
for(int j=0;j<=2;j++)
{
    m=b[1]/b[2];
}
{
    printf("'4' is %d times of 1",m);
}
}