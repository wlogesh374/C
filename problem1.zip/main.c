#include <stdio.h>
int main()
{
    int i, j,n;
        printf("Enter the size of array; ");
       scanf ("%d",&n);
    int a[n],count=-1;

    printf("Enter the elements; ");

    for (i=0;i<n;i++)
    {
        scanf ("%d",&a[i]);
    }


 for(i=0;i<n;i++)
 {
    count++;
    i+=a[i];
    if(i>1)
    {
        i--;
    }
}


    printf("Output:%d\n",count);



}



