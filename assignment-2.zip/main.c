#include<stdio.h>
void main()
{
    int i,j;
    int a[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    
    for(i=0;i<3;i=i+1)
    {
         printf("%d ",a[i][0]);
         printf("\n");
    }
}
