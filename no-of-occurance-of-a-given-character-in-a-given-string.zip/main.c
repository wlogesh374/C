#include <stdio.h>
#include <string.h>
int main()
    {
        char str[25],ch;
        int i,len;
        int count=0;
         printf("enter a character");
        scanf("%c",&ch);
        printf("enter a string\n");
        scanf("%s",str);
        len=strlen(str);
        printf("position of a given charcter %c are\n",ch);
        for(i=0;i<len;i++)
        {
           
      if(str[i]==ch)
    {
           count++;
           printf("%d\n",i);
           
    }
        }
        printf("count is %d",count);
    }
        
        
    