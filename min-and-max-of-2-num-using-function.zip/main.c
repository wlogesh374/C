#include<stdio.h>
int max(int a, int b);
int min(int a,int b);
int main()
{   int a,b;
    printf("enter the numbers \n");
    scanf("%d%d",&a,&b);
    max(a,b);
    //min(a,b);
    return 0;
}
int max(int a, int b)
{
    if(a>b)
    { 
        printf("%d is max\n",a);
          printf("%d is min",b);
    }
    else
    {
        printf("%d is max\n",b);
        printf("%d is min",a);
    } 
}
