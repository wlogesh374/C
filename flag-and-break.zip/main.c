#include<stdio.h>
int main()
{
    int num,i,flag=0;
    printf("Enter the number");
    scanf("%d",&num);
    for(i=2;i<num;i=i+1)
    if(num%i==0)
    {
        flag=1;
        break;
    }
    else
    {
        flag=0;
    }
    if(flag==0)
    {
        printf("%d is prime",num);
    }
    else
    {
        printf("%d is non prime",num);
    }
}