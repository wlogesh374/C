#include <stdio.h>
int cube(int a);
int main()
{
    int a;
    scanf("%d",&a);
    cube(a);

    return 0;
}
int cube(int a)
{
    int b= a * a * a;
    printf("%d ",b);
}
