
#include <stdio.h>
#include <stdlib.h>
int swap();
struct node
{
    int data;
    struct node* next;
}*head,*temp,*newnode,*tail,*t1;

int main()
{
    int n,i,r,choice=1;
    
    printf("enter the data\n");
   while(choice==1) 
{
    newnode=malloc(sizeof(struct node));
       scanf("%d",&newnode->data);
    if(head==0)
   tail= head=newnode;
   else
   {
       tail->next=newnode;
       tail=newnode;
   }
   
   if(newnode->data<0)
   choice=0;
    
}

//swap();
display();
}


int swap()
{
    temp=head;
    
    while(temp!=0)
    {
        t1=temp;
        temp=temp->next;
        temp=t1;
        
        temp=temp->next->next;
        
    }
    
}

void display()
{
    temp=head;
    while(temp!=0)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
}