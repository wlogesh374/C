#include <stdio.h>

int main()
{
    int i;
    int mark [5];
    printf("Enter the Mark ");
    for(i=0;i<5;i++)
    {
        scanf("%d",&mark[i]);
    }
    for(i=0;i<5;i=i+1)
    {
        printf("%d",mark[i]);
    }

    return 0;
}


