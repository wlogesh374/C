#include <stdio.h>
void main()
{
    int N,a[N];
    int i,sum[N/2];
    int total=0;
    printf("Enter the size of array ");
    scanf("%d",&N);
    printf("Enter the elements\n");
    for(i=0;i<N;i++)
    {
    scanf("%d",&a[i]);
    }
    for(i=0;i<(N/2);i++)
    {
        sum[i]=a[i]+a[N-1-i];
    }
     for(i=0;i<(N/2);i++)
     {
         
    printf("sum[%d]=%d ",i+1,sum[i]);
     }
     printf("\n");
     for(i=0;i<(N/2);i++)
     {
         total=total+sum[i];
     }
     printf("total is %d ",total);
}
