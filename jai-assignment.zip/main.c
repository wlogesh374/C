

#include <stdio.h>
#include<string.h>
void main()
{
char name[2][7];
 int i,j;
    char a [5][10]={"sri","nivi","priya","jai"};
    int b [5]={90,66,79,78,98};
    
    printf("enter the name 1 and name 2 ");
    for(i=0;i<2;i++)
    {
    scanf(" %s",&name[i]);
    }
    for ( i=0;i<5;i++)
    {
        if(strcmp(name[0],a[i])==0);
        {
           /* printf ("%d \n",b[i]);
        */
        }
    }
        for (j=0;j<5;j++)
        {
            if (strcmp (name[1], a[j])==0);
        }
        {
            /*printf ("%d\n",b[j]);
    */
    }
        if (b[i]>b[j])
        {
            printf ("student 1 is greater ");
        }
        else
        {
            printf ("student 2 is greater");
        }
    
    }



