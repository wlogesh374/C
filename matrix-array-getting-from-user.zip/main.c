#include<stdio.h>
void main()
{
    int i,j,r,c;
    printf("enter the row and column");
    scanf("%d%d",&r,&c);
    int a[r][c];
    printf("Enter the elements");
    for(i=0;i<r;i=i+1)
    {
        for(j=0;j<c;j++)
        {
            scanf("%d ",&a[i][j]);
        }
    }
    
    for(i=0;i<r;i=i+1)
    {
        for(j=0;j<c;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
}