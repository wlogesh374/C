#include <stdio.h>

int main()
{
    int a[5]={1,2,3,4,5};
    int *p;
    for(p=&a[0];p<=&a[4];p++)
    {
        printf("%d ",*p);
    
    }
  
}