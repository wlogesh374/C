#include <stdio.h>
int main()
{
    char s1[20];
    int s2[10],n1,n2,i,j;
    
    printf("Enter the size of s1 and s2");
    scanf("%d%d",&n1,&n2);
    printf(" enter the values in s1");
    for(i=0;i<7;i++)
    {
    scanf("%c",&s1[i]);
    }
    printf("enter values in s2");
    for(i=0;i<3;i++)
    { 
      scanf("%d",&s2[i]);
    }
      for(i=0;i<n1;i++)
      {
          for(j=0;j<n2;j++)
          {
              if (s1[i]==s2[j])
              {
                  printf("output: %d",i);
                   break;
                   
              }}}
             
}
              


