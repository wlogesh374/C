/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int i, j, n,b,k,flag=0;
        printf("Enter the size \n");
        scanf("%d", &n);
        
        int a[n];
        
        printf("Enter the numbers \n");
      
        for (i = 0; i < n;i++) 
         scanf("%d", &a[i]);    
    
    
for (i = 0; i < n - 2; i++) {
        for ( j = i + 1; j < n - 1; j++) {
            for (k = j + 1; k < n; k++) {
                if (a[i] + a[j] + a[k] == 0)
                {
                    printf("[%d ,%d ,%d]\n", a[i], a[j],a[k]);
                
                }
            }
        }
    }
 
    return 0;
}
