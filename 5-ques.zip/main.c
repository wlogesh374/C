#include <stdio.h>

 int main()
 
 {
     int orderidurationtime,orderistarttime,orderiprice,order1price;
     int t,o,i,j,orderjdurationtime,price;
        printf("enter the no of test cases;");
      scanf("%d",&t);
      while(t--)
      {
          printf("enter the no of orders\n");
          scanf("%d",&o);
          for(i=1;i<=o;i++)
          {
              
      
      printf("Enter the order %d start  :",i);
      scanf("%d",&orderistarttime);
      printf("enter the order%d dur :",i);
      scanf("%d",&orderidurationtime);
      printf("enter the order %d price :",i);
      scanf("%d",&orderiprice);
          }
      
      
           

      for(j=1;j<=o;j++)
      {
          for(i=j+1;i<=o;i++)
          { 
              printf("i is %d\n",i);
            if(orderistarttime < orderjdurationtime)
              {
                 
             printf("i is %d \n",i);
                  price=orderiprice;
                  //  printf("price is %d",price);
              }

          }
      }
      i=1;
      printf("%d",price+orderiprice);
      
      }
  }
