#include <stdio.h>
int swap(int *p,int*q);
void main ()
{
    int a,b;
a=10;
b=30;
swap(&a,&b);
printf("a=%d\nb=%d ",a,b);

}
int swap(int*p,int*q)
{
    int temp;
    temp=*p;
    *p=*q;
    *q=temp;
}