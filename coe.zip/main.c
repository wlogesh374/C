#include <stdio.h>
struct electricity
{
    int id;
    char name[30];
    int units;
    float amt;
    float suramt;
    float totamt;
}c;
int main()
{ 
    struct electricity s;
  struct electricity *ptr;
  
   printf("Enter the customer ID: ");
   scanf("%d",&ptr->id);
     printf("Enter the name of the customer :");
   scanf("%s",ptr->name);
    printf("Enter the unit consumed : ");
  scanf("%d",&ptr->units);
   if(ptr->units<200)
   {
      ptr->amt=ptr->units * 1.20;
   }
   else if(ptr->units>=200&&ptr->units<400)
   {
              ptr->amt=ptr->units * 1.50;

   }
      else if(ptr->units>=400&&ptr->units<600)
      {
                ptr->amt=ptr->units * 1.80;

      }
    else
    {
               ptr->amt=ptr->units * 2;

    }
    if (ptr->amt >400)
    {
        ptr->suramt= ptr->amt * 0.15;
         ptr->totamt= ptr->amt + ptr->suramt;
    }

    if(ptr->amt<100)
    {        printf("\nElectricity Bill\n");
        printf("Customer IDNO                       :%d\n",ptr->id);
        printf("Customer Name                       :%s\n",ptr->name);
        printf("unit Consumed                       :%d\n",ptr->units);
        printf("The minimum amount paid is to be 100/-");
    }
    else
    {
         printf("\nElectricity Bill\n");
   printf("Customer IDNO                       :%d\n",ptr->id);
   printf("Customer Name                       :%s\n",ptr->name);
   printf("unit Consumed                       :%d\n",ptr->units);
   printf("Amount Charges                      :%8.2f\n",ptr->amt);
   printf("Surchage Amount                     :%8.2f\n",ptr->suramt);
   printf("Net Amount Paid By the Customer     :%8.2f\n",ptr->totamt);

    }
   
    return 0;
}

