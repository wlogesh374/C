#include <stdio.h>

int main()
{

        int i, j, n,b,k,flag=0;
        printf("Enter the size \n");
        scanf("%d", &n);
        
        int a[n];
        
        printf("Enter the numbers \n");
      
        for (i = 0; i < n;i++) 
         scanf("%d", &a[i]);
         
         
         for(i=0;i<n;i++)
         {
             for(j=i-1,k=i+1;j>=0,k<n;j--,k++)
             {
                 if(a[i]>a[j] && a[i]<a[k])
                 {
                     flag=1;
                     b=i-1;
                 }
                 
             }
         }
         
         
         if(flag==1)
         printf("%d ",b);
         else
         printf("-1");
    
    
   return 0;
}

