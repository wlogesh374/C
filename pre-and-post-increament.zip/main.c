#include <stdio.h>

int main()
{
   
int a=10;
printf("%d",a++ + ++a + a++);
    return 0;
}

