#include <stdio.h>

int main()
{

        int i, j, n,b=0,sum=0,y,z,x;
        printf("Enter the size \n");
        scanf("%d", &n);
        
        int a[n];
        
        printf("Enter the numbers \n");
      
        for (i = 0; i < n;i++) 
         scanf("%d", &a[i]);
         
          printf("Enter the value of x \n");
        scanf("%d", &x);
        
       
         b=x-a[0]-a[1];
        
         for(i=0;i<n;i++)
         {
             for(j=i+1;j<n;j++)
             {
                 sum=x-a[i]-a[j];
                 if(sum<0)
                 sum=(-1*sum);
                 
                // printf("%d\n",sum);
                
                 if(sum<b)
                 {
                     b=sum;
                 y=i,z=j;
                 }
             }
         }
         
         
         
         printf("%d and %d",a[y],a[z]);
         
}