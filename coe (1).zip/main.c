#include <stdio.h>
struct electricity
{
    int id;
    char name[30];
    int units;
    float amt;
    float suramt;
    float totamt;
}c;
int main()
{ 

   printf("Enter the customer ID: ");
   scanf("%d",&c.id);
     printf("Enter the name of the customer :");
   scanf("%s",c.name);
    printf("Enter the unit consumed : ");
   scanf("%d",&c.units);
   if(c.units<200)
   {
      c.amt=c.units * 1.20;
   }
   else if(c.units>=200&&c.units<400)
   {
              c.amt=c.units * 1.50;

   }
      else if(c.units>=400&&c.units<600)
      {
                c.amt=c.units * 1.80;

      }
    else
    {
               c.amt=c.units * 2;

    }
    if (c.amt >400)
    {
        c.suramt= c.amt * 0.15;
         c.totamt= c.amt + c.suramt;
    }

    if(c.amt<100)
    {        printf("\nElectricity Bill\n");
        printf("Customer IDNO                       :%d\n",c.id);
        printf("Customer Name                       :%s\n",c.name);
        printf("unit Consumed                       :%d\n",c.units);
        printf("The minimum amount paid is to be 100/-");
    }
    else
    {
         printf("\nElectricity Bill\n");
   printf("Customer IDNO                       :%d\n",c.id);
   printf("Customer Name                       :%s\n",c.name);
   printf("unit Consumed                       :%d\n",c.units);
   printf("Amount Charges                      :%8.2f\n",c.amt);
   printf("Surchage Amount                     :%8.2f\n",c.suramt);
   printf("Net Amount Paid By the Customer     :%8.2f\n",c.totamt);

    }
   
    return 0;
}
