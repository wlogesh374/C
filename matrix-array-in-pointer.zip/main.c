/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a[][2]={{1,2},{3,4}};
    int *p;
    p=&a[0][0];
    for(p=&a[0][0];p!=&a[1][2];p++)
    {
        printf("%d ",*p);
        
    }
}
